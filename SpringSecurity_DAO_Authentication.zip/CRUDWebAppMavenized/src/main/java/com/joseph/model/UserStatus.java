package com.joseph.model;

public enum UserStatus {
	ACTIVE,
	INACTIVE;
}
